# Remote build verification session note — trade transformer contract fix (2026-06-07)

This note captures a concrete failure pattern from the trade repo Docker Build Validation workflow and the verification flow used to diagnose it.

## Evidence pattern

- Verify the exact workflow run created by the push, not just the latest branch run.
- Match both:
  - branch
  - `headSha`
- Require the run to reach `status=completed` and `conclusion=success` before reporting success.
- For matrix builds, inspect the required job list, not only the first green lane.

## What happened in this session

- The backend image built successfully far enough to run tests.
- `ctest` failed on `transformer_onnx_export`.
- The failure text was:
  - `Transformer ONNX export wrote an unexpected input_layout:`
- Root cause:
  - the test called the low-level ONNX exporter directly, which writes the ONNX payload but not the companion `transformer_config.json` sidecar
  - the test was meant to validate the full package contract, including the config metadata

## Fix pattern

If a smoke test is meant to validate package metadata or a generated sidecar file:

- call the higher-level packaging/export API that writes the sidecar
- do not call only the bare artifact exporter unless the test is intentionally scoped to the raw payload

## Remote verification command sequence

1. Find the exact run for the pushed commit.
2. Query the run JSON for `status`, `conclusion`, `headSha`, and `url`.
3. Query the job list for the required matrix jobs.
4. If the run is still in progress, keep polling the same run id.
5. If a job fails, use `gh run view <run_id> --log-failed` or `gh api .../jobs` to identify the failing test and assertion text.

## Useful rule of thumb

A build can be “green enough to compile” and still fail CI on a contract assertion. When that happens, trust the failing test output and inspect the test harness first.
