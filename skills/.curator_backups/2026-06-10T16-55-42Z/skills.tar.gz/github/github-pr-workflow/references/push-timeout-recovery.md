# Push timeout recovery

If a push call times out, treat the result as inconclusive instead of assuming failure.

Observed recovery pattern:
1. Check repo state first (`git status`, branch ahead/behind, and fetch from origin).
2. If the local branch is already ahead by the expected commit and the working tree is clean, the push may have completed on the server side despite the client timeout.
3. Avoid repeating the exact same push call in a tight loop; change strategy only after checking the remote state.
4. When the branch is still unpublished, retry with a different transport or a direct shell push if the MCP path is timing out.

Useful verification signals:
- Local branch ahead/behind counts
- Remote ref updated after fetch
- Working tree clean after the commit
