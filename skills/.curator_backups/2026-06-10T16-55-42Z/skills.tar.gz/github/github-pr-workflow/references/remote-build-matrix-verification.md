# Remote build verification: exact push → run-id → matrix jobs

Use this checklist when the user asks you to push a change and verify the resulting GitHub Actions build.

1. Push the commit, then immediately capture the new run with `gh run list --branch <branch> --limit ...`.
2. Match the intended run by both branch and `headSha`.
3. Verify the exact run id with `gh run view <run_id> --json status,conclusion,headSha,url,name,headBranch,jobs`.
4. Treat the run as unresolved until `status=completed` and `conclusion=success`.
5. For matrix workflows, require every required job to complete successfully; do not treat a subset of green jobs as proof.
6. If `gh run watch` times out or keeps printing annotations, keep polling the same run id with `gh run view` instead of switching to a newer run.
7. If frontend/publish jobs complete while backend jobs are still running, the workflow is still in progress.
8. When reporting success, include the run URL and the verified `headSha` so the proof is unambiguous.