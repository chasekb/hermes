# GitHub Actions Verification Evidence

Minimal proof bundle for a remote build verification answer:

- Run URL: `https://github.com/<owner>/<repo>/actions/runs/<run_id>`
- Branch / ref that generated the run
- Verified `headSha`
- Workflow name
- Terminal `status`
- Terminal `conclusion`
- Required job names and their final states

Rules:
- Only mark success when `status=completed` and `conclusion=success`.
- For matrix workflows, all required jobs must be complete and successful.
- If one job is still running, the run is unresolved.
- Prefer the run created by the latest push that matches the exact `headSha` being discussed.

This evidence bundle is the default answer shape when the user says to use GitHub Actions as the source of truth.