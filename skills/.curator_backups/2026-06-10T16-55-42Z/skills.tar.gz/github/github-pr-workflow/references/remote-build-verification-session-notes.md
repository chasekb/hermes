# Remote Build Verification Session Notes

This note captures a concrete field pattern for verifying a build via GitHub Actions when the user wants the workflow itself to be the source of truth.

## Evidence bundle to report back

Always include:
- exact workflow run URL
- verified `headSha`
- terminal `status`
- terminal `conclusion`
- the required job names that mattered for the proof

Do not say the build succeeded until the run is `completed` and `conclusion=success`.
If a matrix workflow is involved, every required job must be terminally successful.

## Polling discipline

Prefer repeated `gh run view <RUN_ID> --json status,conclusion,jobs,headSha,url` calls over guessing from local logs.
If the run is still `in_progress`, keep polling the same run id instead of switching to a newer run on the same branch.

## Practical lesson from this session

A successful remote build report should make the verification anchor obvious:
- workflow: `Docker Build Validation`
- branch: the branch that produced the run
- commit: the exact `headSha`
- result: only after every required job finished

If a run is still active, say so plainly and do not overstate progress.