# Remote build verification session note (2026-06-06)

Context:
- Repository: `trade`
- Branch used for verification: `ci-fix`
- Commit pushed: `2df0c5a031cd560815db27666f7db89c7da61d75`
- Workflow: `Docker Build Validation`
- Run URL: `https://github.com/chasekb/trade/actions/runs/27055540976`

Observed verification pattern:
1. Push the commit to the branch that triggers Actions.
2. Query the exact workflow run created by that push.
3. Match by both branch and `headSha` before treating the run as authoritative.
4. Poll the same run id until the run reaches a terminal state.
5. Do not report success while any required job is still in progress.

Useful commands:
- `gh run list --branch ci-fix --limit 10 --json databaseId,status,conclusion,workflowName,headSha,displayTitle,url,createdAt`
- `gh run view 27055540976 --json status,conclusion,jobs,url,workflowName,headSha,displayTitle`
- Fallback when the GitHub API blips: `gh api /repos/chasekb/trade/actions/runs/27055540976`

Notes:
- In this session, the frontend job finished first while the backend job kept running, so the workflow remained unresolved.
- The correct reporting posture was "in progress" until the backend job completed.
- This is a good template for future remote-build proof: exact run URL + exact headSha + terminal status/conclusion + job-level confirmation.