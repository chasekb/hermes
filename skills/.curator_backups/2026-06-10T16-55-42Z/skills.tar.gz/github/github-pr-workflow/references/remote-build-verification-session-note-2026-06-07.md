# Remote build verification session note (trade, 2026-06-07)

This session reinforced a few verification habits for GitHub Actions after a push:

- The authoritative proof bundle is the exact run URL, the verified `headSha`, and the terminal `status`/`conclusion` from the run JSON.
- When a workflow is a matrix build, inspect the job list and require every required job to finish. One lane turning green is not enough if another required lane is still running.
- `gh run view <run_id> --json status,conclusion,jobs,url,workflowName,headSha,displayTitle` is the preferred single-shot check.
- If `gh run view` times out on the GitHub API, fall back to `gh api repos/<owner>/<repo>/actions/runs/<run_id>` and `gh api repos/<owner>/<repo>/actions/runs/<run_id>/jobs` to keep verifying the same run id.
- `gh run watch` is convenient for live progress, but it is not the proof source; the final report should still cite the exact run URL and headSha from the run JSON/API.
- When a run is still `in_progress`, do not substitute an older successful run from the same branch. Always match the pushed commit SHA.

Observed example:

- Repository: `chasekb/trade`
- Workflow: `Docker Build Validation`
- Run URL: `https://github.com/chasekb/trade/actions/runs/27079762789`
- Head SHA: `e9d93e16f609aedbcc8cb41c62b2d14a4b22cfb6`
- Status at the time of inspection: `in_progress`
- Job state snapshot: frontend completed successfully, backend still running
